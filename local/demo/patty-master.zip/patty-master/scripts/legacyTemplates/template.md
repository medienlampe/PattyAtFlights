```jsx
<{{placeHolderForName}} />
```