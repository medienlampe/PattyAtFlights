/**
 * This is just a dummy file to give you an example, please create your own accordingly.
 * You can then run it via `npm run bundleLegacy <yourfile>` (omit the '.js'!).
 * So for this very file this would be `npm run bundleLegacy demo` - but don't use it, 
 * as it would fail because the components here don't exist. ;)
 */
import { renderDemoComponent } from '../DemoComponent/DemoComponent.js';
export { renderDemoComponent };
